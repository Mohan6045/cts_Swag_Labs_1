package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class About_Page {
	
	// //a[@href='https://saucelabs.com/']\
	WebDriver dr;

	
	public About_Page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void link_for_aboutpage() {                                  // navigating to the about page 
		System.out.println("link clicked");
		dr.findElement(By.xpath("//div[@class='bm-burger-button']")).click();
		
		
	}
	
	public void About_Saucedemo() throws InterruptedException {       // Clicking on the about link
		
		Thread.sleep(100);
		dr.findElement(By.xpath("//nav[@class='bm-item-list']//child::a[2]")).click();
		
	}
	public void any_btn()                                    // Clicking on the  learn More in sauce demo
	{
		// //div[@class='content-container']//following::a[1]
		dr.findElement(By.xpath(" //div[@class='content-container']//following::a[1]")).click();
		
	}

}
